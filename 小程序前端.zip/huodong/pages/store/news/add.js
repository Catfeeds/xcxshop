//index.js
var app = getApp()
Page({
  data: {

  },

  onLoad: function () {
    console.log(app.globalData);
  }

})